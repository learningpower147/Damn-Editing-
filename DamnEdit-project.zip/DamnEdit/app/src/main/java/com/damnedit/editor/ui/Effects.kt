package com.damnedit.editor.ui

import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment

/** One shared effect list, used for BOTH preview and export so they match. */
@OptIn(UnstableApi::class)
fun buildEffects(brightness: Float, contrast: Float, saturation: Float): List<Effect> {
    val list = ArrayList<Effect>()
    if (brightness != 0f) list.add(Brightness(brightness))
    if (contrast != 0f) list.add(Contrast(contrast))
    if (saturation != 0f) list.add(HslAdjustment.Builder().adjustSaturation(saturation * 100f).build())
    return list
}
