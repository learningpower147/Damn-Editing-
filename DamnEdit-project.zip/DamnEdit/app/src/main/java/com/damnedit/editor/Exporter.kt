package com.damnedit.editor

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/** Exports H.264/AAC MP4 with trim + effects applied, then saves it to Movies/DamnEdit. */
@OptIn(UnstableApi::class)
class Exporter(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var polling = false

    fun start(
        source: Uri,
        startMs: Long,
        endMs: Long,
        effects: List<Effect>,
        onProgress: (Float) -> Unit,
        onDone: (Uri) -> Unit,
        onError: (String) -> Unit
    ) {
        val out = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        val item = MediaItem.Builder().setUri(source).setClippingConfiguration(clip).build()
        val edited = EditedMediaItem.Builder(item).setEffects(Effects(emptyList(), effects)).build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    polling = false
                    Thread {
                        try {
                            val saved = saveToMovies(out)
                            out.delete()
                            main.post { onDone(saved) }
                        } catch (e: Exception) {
                            out.delete()
                            main.post { onError("Couldn't save the file. ${e.message ?: ""}") }
                        }
                    }.start()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    polling = false
                    out.delete()
                    onError(exportException.message ?: "Export failed")
                }
            })
            .build()
        transformer = t
        t.start(edited, out.absolutePath)

        polling = true
        val holder = ProgressHolder()
        val tick = object : Runnable {
            override fun run() {
                if (!polling) return
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(holder.progress / 100f)
                }
                main.postDelayed(this, 300)
            }
        }
        main.post(tick)
    }

    fun cancel() {
        polling = false
        transformer?.cancel()
    }

    private fun saveToMovies(file: File): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "DamnEdit_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DamnEdit")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("MediaStore insert failed")
        resolver.openOutputStream(uri)!!.use { os -> file.inputStream().use { it.copyTo(os) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }
}
