package com.damnedit.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.damnedit.editor.ui.DamnPaletteSwatch
import com.damnedit.editor.ui.EditorScreen
import com.damnedit.editor.ui.HomeScreen
import com.damnedit.editor.ui.theme.DamnEditTheme
import com.damnedit.editor.ui.theme.DamnPalette

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var palette by rememberSaveable { mutableStateOf(DamnPalette.PLUM) }
            var videoUri by rememberSaveable { mutableStateOf<Uri?>(null) }
            DamnEditTheme(palette) {
                val current = videoUri
                if (current == null) {
                    HomeScreen(palette, onPalette = { palette = it }, onPicked = { videoUri = it })
                } else {
                    EditorScreen(current, onClose = { videoUri = null })
                }
            }
        }
    }
}
