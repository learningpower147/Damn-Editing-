package com.damnedit.editor.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// NOTE: written but NOT compiled or tested yet. Palette base colours come from
// the user's three palette images; the "derived" ones are darker/lighter steps
// of those colours so the UI has enough depth.

enum class DamnPalette { PLUM, FOREST, WINE }

data class DamnColors(
    val background: Color,   // derived (darker than surface)
    val surface: Color,      // palette dark colour
    val surfaceHigh: Color,  // derived (lighter than surface)
    val onSurface: Color,    // palette light colour
    val muted: Color,        // derived
    val accent: Color,       // palette light colour (primary buttons)
    val onAccent: Color,     // palette dark colour
    val clipA: Color,
    val clipB: Color,        // derived
    val clipC: Color,        // derived
    val outline: Color       // derived
)

val PlumColors = DamnColors(
    background = Color(0xFF2A1226), surface = Color(0xFF381932), surfaceHigh = Color(0xFF4B2843),
    onSurface = Color(0xFFFFF3E6), muted = Color(0xFFCDB6BE),
    accent = Color(0xFFFFF3E6), onAccent = Color(0xFF381932),
    clipA = Color(0xFFFFF3E6), clipB = Color(0xFFC79AB8), clipC = Color(0xFFEBB59C),
    outline = Color(0xFF5A3652)
)

val ForestColors = DamnColors(
    background = Color(0xFF04301F), surface = Color(0xFF064734), surfaceHigh = Color(0xFF0E5C45),
    onSurface = Color(0xFFE0FFC2), muted = Color(0xFFA6CBA0),
    accent = Color(0xFFE0FFC2), onAccent = Color(0xFF064734),
    clipA = Color(0xFFE0FFC2), clipB = Color(0xFF86CC9E), clipC = Color(0xFFC9E88C),
    outline = Color(0xFF1A6650)
)

val WineColors = DamnColors(
    background = Color(0xFF560116), surface = Color(0xFF7F011F), surfaceHigh = Color(0xFF9A2139),
    onSurface = Color(0xFFF5EBD0), muted = Color(0xFFDDBBB0),
    accent = Color(0xFFF5EBD0), onAccent = Color(0xFF7F011F),
    clipA = Color(0xFFF5EBD0), clipB = Color(0xFFE09096), clipC = Color(0xFFE9CB8A),
    outline = Color(0xFFA23A50)
)

val LocalDamnColors = staticCompositionLocalOf { PlumColors }

@Composable
fun DamnEditTheme(palette: DamnPalette = DamnPalette.PLUM, content: @Composable () -> Unit) {
    val c = when (palette) {
        DamnPalette.PLUM -> PlumColors
        DamnPalette.FOREST -> ForestColors
        DamnPalette.WINE -> WineColors
    }
    val scheme = darkColorScheme(
        primary = c.accent, onPrimary = c.onAccent,
        background = c.background, onBackground = c.onSurface,
        surface = c.surface, onSurface = c.onSurface,
        surfaceVariant = c.surfaceHigh, onSurfaceVariant = c.muted,
        outline = c.outline
    )
    androidx.compose.runtime.CompositionLocalProvider(LocalDamnColors provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
