package com.damnedit.editor.ui

import android.content.Intent
import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.damnedit.editor.Exporter
import com.damnedit.editor.ui.theme.LocalDamnColors
import kotlinx.coroutines.delay

private sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Failed(val message: String) : ExportState
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(uri: Uri, onClose: () -> Unit) {
    val c = LocalDamnColors.current
    val context = LocalContext.current

    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
        }
    }
    var durationMs by remember { mutableLongStateOf(0L) }
    var range by remember { mutableStateOf(0f..1f) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(0f) }
    var saturation by remember { mutableFloatStateOf(0f) }
    var export by remember { mutableStateOf<ExportState>(ExportState.Idle) }
    val exporter = remember { Exporter(context.applicationContext) }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && player.duration > 0) durationMs = player.duration
            }
        }
        player.addListener(l)
        onDispose {
            player.removeListener(l)
            player.release()
            exporter.cancel()
        }
    }

    // Live preview of the same effects that get exported.
    LaunchedEffect(brightness, contrast, saturation) {
        player.setVideoEffects(buildEffects(brightness, contrast, saturation))
    }

    val startMs = (range.start * durationMs).toLong()
    val endMs = (range.endInclusive * durationMs).toLong()

    // Keep preview playback inside the trimmed range.
    LaunchedEffect(startMs, endMs) {
        while (true) {
            delay(100)
            if (durationMs > 0 && player.isPlaying && player.currentPosition >= endMs) {
                player.pause()
                player.seekTo(startMs)
            }
        }
    }

    val sliderColors = SliderDefaults.colors(
        thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.outline
    )

    Column(Modifier.fillMaxSize().background(c.background).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = c.onSurface)
            }
            Button(
                enabled = durationMs > 0 && export !is ExportState.Running,
                onClick = {
                    player.pause()
                    export = ExportState.Running(0f)
                    val end = if (range.endInclusive >= 0.999f) C.TIME_END_OF_SOURCE else endMs
                    exporter.start(
                        source = uri,
                        startMs = startMs,
                        endMs = end,
                        effects = buildEffects(brightness, contrast, saturation),
                        onProgress = { p -> export = ExportState.Running(p) },
                        onDone = { out -> export = ExportState.Done(out) },
                        onError = { msg -> export = ExportState.Failed(msg) }
                    )
                },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = c.accent, contentColor = c.onAccent,
                    disabledContainerColor = c.outline, disabledContentColor = c.muted
                )
            ) { Text("Export", fontWeight = FontWeight.Medium) }
        }

        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxWidth().weight(1f).heightIn(min = 180.dp)
        )

        Column(
            Modifier.fillMaxWidth().heightIn(max = 330.dp).verticalScroll(rememberScrollState())
                .background(c.surface).padding(16.dp)
        ) {
            when (val e = export) {
                is ExportState.Running -> {
                    Text("Exporting… ${(e.progress * 100).toInt()}%", color = c.onSurface, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { e.progress }, modifier = Modifier.fillMaxWidth(),
                        color = c.accent, trackColor = c.outline
                    )
                    TextButton(onClick = { exporter.cancel(); export = ExportState.Idle }) {
                        Text("Cancel", color = c.accent)
                    }
                }
                is ExportState.Done -> Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Saved to Movies/DamnEdit", color = c.onSurface, fontSize = 14.sp)
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"
                            putExtra(Intent.EXTRA_STREAM, e.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    }) { Icon(Icons.Default.Share, contentDescription = "Share", tint = c.accent) }
                }
                is ExportState.Failed -> Text(
                    "Export failed: ${e.message}", color = c.clipC, fontSize = 13.sp
                )
                ExportState.Idle -> {}
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Trim", color = c.onSurface, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text("${fmt(startMs)} – ${fmt(endMs)}", color = c.muted, fontSize = 12.sp)
            }
            RangeSlider(
                value = range,
                onValueChange = { v ->
                    val startChanged = v.start != range.start
                    range = v
                    if (durationMs > 0) {
                        player.seekTo(if (startChanged) (v.start * durationMs).toLong()
                                      else (v.endInclusive * durationMs).toLong())
                    }
                },
                colors = sliderColors
            )
            LabeledSlider("Brightness", brightness, sliderColors) { brightness = it }
            LabeledSlider("Contrast", contrast, sliderColors) { contrast = it }
            LabeledSlider("Saturation", saturation, sliderColors) { saturation = it }
            TextButton(onClick = { brightness = 0f; contrast = 0f; saturation = 0f }) {
                Text("Reset colour", color = c.accent)
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float,
    colors: androidx.compose.material3.SliderColors,
    onChange: (Float) -> Unit
) {
    val c = LocalDamnColors.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = c.onSurface, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Text("${(value * 100).toInt()}", color = c.muted, fontSize = 12.sp)
    }
    Slider(value = value, onValueChange = onChange, valueRange = -1f..1f, colors = colors)
}
