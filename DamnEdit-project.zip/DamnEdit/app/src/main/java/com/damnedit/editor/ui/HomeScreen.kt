package com.damnedit.editor.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.damnedit.editor.ui.theme.DamnPalette
import com.damnedit.editor.ui.theme.ForestColors
import com.damnedit.editor.ui.theme.LocalDamnColors
import com.damnedit.editor.ui.theme.PlumColors
import com.damnedit.editor.ui.theme.WineColors

fun DamnPaletteSwatch(p: DamnPalette): Color = when (p) {
    DamnPalette.PLUM -> PlumColors.surface
    DamnPalette.FOREST -> ForestColors.surface
    DamnPalette.WINE -> WineColors.surface
}

@Composable
fun HomeScreen(palette: DamnPalette, onPalette: (DamnPalette) -> Unit, onPicked: (Uri) -> Unit) {
    val c = LocalDamnColors.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onPicked(uri)
    }
    Column(
        Modifier.fillMaxSize().background(c.background).systemBarsPadding().padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(c.accent),
                contentAlignment = Alignment.Center
            ) { Text("D", color = c.onAccent, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("DamnEdit", color = c.onSurface, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Edit. Create. Beyond limits.", color = c.muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("New project", fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(28.dp))
        Text("Quick edit", color = c.onSurface, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface).padding(18.dp)
        ) {
            Text("Pick a video to start", color = c.onSurface, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                "Trim it, adjust brightness, contrast and saturation, then export an MP4 to Movies/DamnEdit. Everything stays on your phone.",
                color = c.muted, fontSize = 13.sp, lineHeight = 19.sp
            )
        }
        Spacer(Modifier.weight(1f))
        Text("Colour theme", color = c.muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DamnPalette.values().forEach { p ->
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(DamnPaletteSwatch(p))
                        .border(if (p == palette) 2.dp else 1.dp, if (p == palette) c.accent else c.outline, CircleShape)
                        .clickable { onPalette(p) }
                )
            }
        }
    }
}
