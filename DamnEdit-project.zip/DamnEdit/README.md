# DamnEdit (MVP foundation, v0.1.0)

Status: source written but NOT yet compiled or tested. Expect to fix small build errors on first run.

## What works in this build (intended)
- Pick a video with the system picker (no storage permission needed)
- Preview with live brightness / contrast / saturation
- Trim start/end
- Export H.264/AAC MP4 with trim + colour applied -> Movies/DamnEdit, share sheet
- Three colour themes (Plum, Forest, Wine Red) on the home screen
- No network permission, no accounts, fully offline

## NOT built yet
Multi-clip timeline, split, masks (manual/AI), keyframes, text, audio tracks, transitions, project saving.
Min Android 10 (API 29).

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo, upload ALL files of this folder (keep the .github folder).
2. Open the Actions tab -> "Build APK" -> wait for the green tick (~5-8 min).
3. Open the run -> Artifacts -> download DamnEdit-debug-apk -> unzip -> install app-debug.apk.
If the run is red, open it and send me the error text.
